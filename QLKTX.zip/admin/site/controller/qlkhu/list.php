<?php 
$qlkhu = new qlkhu();
include_once('site/view/qlkhu/list.php');
?>