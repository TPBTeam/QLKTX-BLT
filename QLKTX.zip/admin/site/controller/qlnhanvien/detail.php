<?php  
require "libs/connect.php";

require "site/view/qlnhanvien/detail.php";
?>