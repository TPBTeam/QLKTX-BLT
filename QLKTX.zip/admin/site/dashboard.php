<?php 
require "template/components/header.php";
require "template/components/siderbar.php";
?>
<!-- Page Content  -->

<?php 
require "template/components/footer.php";
?>