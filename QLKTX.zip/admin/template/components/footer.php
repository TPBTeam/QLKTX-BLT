</div>
</div>
<!-- jQuery CDN - Slim version (=without AJAX) -->
<script src="../public/js/jquery-3.3.1.min.js"></script>
<!-- Popper.JS -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script> -->
<!-- Bootstrap JS -->
<script src="../public/js/bootstrap.min.js"></script>
<!-- Custom JS -->
<script type="text/javascript" src="../public/js/admin.js"></script>
</body>
</html>